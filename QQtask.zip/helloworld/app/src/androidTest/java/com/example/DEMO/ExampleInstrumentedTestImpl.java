package com.example.DEMO;

public class ExampleInstrumentedTestImpl extends ExampleInstrumentedTest {
}

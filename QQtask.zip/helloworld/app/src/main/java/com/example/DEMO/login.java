package com.example.DEMO;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import java.util.Timer;
import java.util.TimerTask;

public class login extends Activity  {
    private datalist dbHelper;
    private Button log_back;
    private   EditText account;
    private   EditText pass;
    String src="";
    String number;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);//----------head
        //找件
        account =findViewById(R.id.ed_account);
        pass =findViewById(R.id.ed_password);
        log_back = findViewById(R.id.login_go);
        //找库
        dbHelper = new datalist(this, "information.db", null, 1);
        dbHelper.getWritableDatabase();
        //按钮响应
        log_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String user = account.getText().toString();
                final String password = pass.getText().toString();

                SQLiteDatabase db=dbHelper.getWritableDatabase();

                 //账号是否输入
                 if(user.equals("")){ Toast.makeText(login.this, "请输入账号", Toast.LENGTH_SHORT).show(); }  //否输入账号
    //输入账号
    else{
                    //查询数据库
                    Cursor cursor=db.query("Relation",null,"账号=?",new String[]{user},null,null,null);
                    if(cursor.moveToFirst()){
                        do{
                            number=cursor.getString(cursor.getColumnIndex("密码"));//根据key值读取信息
                            src+=number;
                        }while (cursor.moveToNext()); }
                    cursor.close();                        //end 查库
                    //未发现账号
                    if(src.equals("")){ Toast.makeText(login.this, "你还没有账号哦，去注册一个吧", Toast.LENGTH_SHORT).show(); }
          //存在账号
          else{
                    //未输入密码
                    if(password.equals("")){Toast.makeText(login.this, "请输入密码", Toast.LENGTH_SHORT).show(); }
              //输入了密码
              else{
                  //密码正确
                  if(password.equals(number)){
                      //成功  one
                      Toast.makeText(login.this, "欢迎来到祖安大世界\nWelcome to ZuAn world ", Toast.LENGTH_SHORT).show();
                      //成功  two
                      Toast.makeText(login.this, "后续内容持续上线中", Toast.LENGTH_LONG).show();
                                              }         //   end  密码正确
                  //密码不正确
                  else{Toast.makeText(login.this, "密码不正确", Toast.LENGTH_SHORT).show();}
              }//输入了密码
          }  //存在账号
    }  //已输入账号

                }    //  the task of Button

        });   //  sign Button

    }   //  player、find

}  //  with private

                                 //  跳转
                                //Intent intent=new Intent(login.this,MainActivity.class);
                                //startActivity(intent);
                                //   延迟
                                /* TimerTask task = new TimerTask(){
                                public void run(){

                                                  }       //  end: in loading
                                    };   //  end  in
                                    Timer timer = new Timer();
                                    timer.schedule(task, 1000);*/

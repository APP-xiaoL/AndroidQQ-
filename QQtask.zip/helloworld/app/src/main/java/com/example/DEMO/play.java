package com.example.DEMO;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class play extends Activity  {
    private  datalist dbHelper;
    private TextView showy;
    private Button find;
    String str="";


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.onplay);
        //寻找控件
        find =findViewById(R.id.look);
        showy=findViewById(R.id.show);
        //创建 表单
        dbHelper = new datalist(this, "information.db", null, 1);
        dbHelper.getWritableDatabase();

        //按钮响应
        find.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                SQLiteDatabase db=dbHelper.getWritableDatabase();
                 Cursor cursor=db.query("Relation",null,null,null,null,null,null);//读取数据库所有信息
                if(cursor.moveToFirst()){
                    do{
                       String number=cursor.getString(cursor.getColumnIndex("账号"));//根据key值读取信息
                        String name=cursor.getString(cursor.getColumnIndex("密码"));
                        String sex=cursor.getString(cursor.getColumnIndex("姓名"));
                        String subject=cursor.getString(cursor.getColumnIndex("联系人"));
                        str+="账号为："+number+";"+ "密码为："+name+";"+ "性别为："+sex+
                              ";"+ "专业为："+subject+"\n";//将数据库信息存到str中并换行
                    }while (cursor.moveToNext());
                }
               cursor.close();
                if(str==""){ showy.setText("无数据null");}else {
                    Toast.makeText(play.this, "查询成功", Toast.LENGTH_LONG).show();
                showy.setText("信息内容information\n"+str);}             //打印信息   不输出为定义值空，if判断用于遍历，每一次显示一个值

            }    //  the task of Button

        });   //  sign Button

    }   //  player、find

}  //  with private
package com.example.DEMO;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class datalist extends SQLiteOpenHelper {
    public static final String CREATE_LIST="create table Relation("
             +"id integer primary key autoincrement,"
            +"账号 text,"
             +"密码 text,"
             +"姓名 text,"
             +"联系人 text)";
    private Context mContext;

    public datalist(Context context, String name,
                            SQLiteDatabase.CursorFactory factory, int version){
        super(context,name,factory,version);
        mContext=context;
    }

    //库    == new datalist
   /* public datalist(Context context){
        super(context,"friend.db",null,1);
    }*/



    @Override//user 可使用的
    public void onCreate(SQLiteDatabase db) {
        //db.execSQL("Create table user(id integer primary key autoincrement,username varchar,pass varchar,name varchar,call varchar)");
        db.execSQL(CREATE_LIST);
        Toast.makeText(mContext, "创建成功", Toast.LENGTH_SHORT).show();
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }


    /*public Cursor query(String relation, Object o, Object o1, Object o2,Object o3) {
        return query(relation,o,o1,o2,o3);
    }
    public Cursor query(String table, String[] columns, String selection,
                        String[] selectionArgs, String groupBy, String having,
                        String orderBy) {

        return query( table, columns, selection, selectionArgs, groupBy,
                having, orderBy, null /* limit */;



}

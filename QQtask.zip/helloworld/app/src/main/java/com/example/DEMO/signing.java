package com.example.DEMO;

import android.app.Activity;

import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Bundle;

import android.database.sqlite.SQLiteDatabase;


import android.widget.EditText;
import androidx.appcompat.app.AlertDialog;


public class signing extends Activity {
       private Button sign_back;
       private EditText pass;
       public datalist dbHelper;
       private String account;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signin);  //显示页面
        //寻找控件
        sign_back = findViewById(R.id.sign_go);       //寻 · 按钮
        pass = findViewById(R.id.password);    //寻 · 文本
        //创建账号
        int math = (int) ((Math.random() * 9 + 1) * 100000);         //创建 · 用户
        account = String.valueOf(math);
        // Toast.makeText(signing.this, account, Toast.LENGTH_LONG).show();  //显示账号

        //创建 表单
        dbHelper = new datalist(this, "information.db", null, 1);
        dbHelper.getWritableDatabase();

        //按钮响应
        sign_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final SQLiteDatabase db = dbHelper.getWritableDatabase();
                //清除内容
                db.delete("Relation",null,null);
                //增加内容
                ContentValues values = new ContentValues();
                final String password = pass.getText().toString();//获取密码
                final String wow =account;
                final String username ="Mr.Yan";
                values.put("账号",wow);
                values.put("密码", password);//存密码
                values.put("姓名", username);
                if (wow==""||password.equals("")) {
                    Toast.makeText(signing.this, "信息不全，请补充", Toast.LENGTH_LONG).show();
                } else {
                    db.insert("Relation", null, values);
                    //注意别漏掉
                    values.clear();
                    Toast.makeText(signing.this, "注册成功", Toast.LENGTH_LONG).show();
                    pass.setText("");//保存成功清空学号和姓名信息
                    //   提示框
                    AlertDialog.Builder builder  = new AlertDialog.Builder(signing.this);
                    builder.setTitle("您的账户信息" ) ;
                    builder.setMessage("账号：" +wow+"                                                 "+"密码："+password) ;
                    builder.setPositiveButton("好的",new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {
                            arg0.dismiss();
                            Intent intent=new Intent(signing.this,login.class);   //加载下页
                            startActivity(intent);
                        }
                    });
                    builder.show();

                }   //  end  储存信息

            }  //  the task of Button

        });  //  sign Button

    }  //  player、find

}  //  with private

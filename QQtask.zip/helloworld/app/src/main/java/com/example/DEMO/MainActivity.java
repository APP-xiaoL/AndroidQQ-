package com.example.DEMO;

import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import org.jetbrains.annotations.NotNull;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends Activity  {                 // implements View.OnClickListener
      private Button sign;
      private  Button log;
      int a=0;int b=0;int c=0;
     /* private Button A;
      private Button B;
      private Button C;
      private TextView toA;
      private TextView toB;
      private TextView toC;*/


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sign = findViewById(R.id.sign);
        log = findViewById(R.id.log);
        //注册
        sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this, signing.class);
                startActivity(intent);
            }
        });
        //登录
        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,login.class);
                startActivity(intent);
            }
        });
        //  查找投票
        /*A=findViewById(R.id.addA);B=findViewById(R.id.addB);C=findViewById(R.id.addC);
        A.setOnClickListener(this);B.setOnClickListener(this);C.setOnClickListener(this);
        toA=findViewById(R.id.toA0);toB=findViewById(R.id.toB0);toC=findViewById(R.id.toC0);*/
             TimerTask task = new TimerTask(){
                public void run(){
                    Intent intent=new Intent(MainActivity.this,play.class);
                    startActivity(intent);
                                  }       //  end: in loading
                    };   //  end  in
                    Timer timer = new Timer();
                    timer.schedule(task, 3600);

    }   //  player、find

   /*@Override
   public void onClick( View view) {
        switch (view.getId()){
            case R.id.addA:
                a++;
               toA.setText(a+"票");
                Toast.makeText(this, "投票成功", Toast.LENGTH_LONG).show();
                break;
            case R.id.addB:
                b++;
                toB.setText(b+"票");
                Toast.makeText(this, "投票成功", Toast.LENGTH_LONG).show();
                break;
            case R.id.addC:
                c++;
               toC.setText(c+"票");
                Toast.makeText(this, "投票成功", Toast.LENGTH_LONG).show();
                break;
            default:
                break;
        }
    }*/


}  //  with private
